NITK PLACEMENT INTELLIGENCE PLATFORM — HACKATHON MVP

RUN:
1. Extract this ZIP.
2. Double-click index.html.
3. It opens in Chrome. No Node.js, npm or server is required. An internet connection lets the NITK Surathkal and Smart India Hackathon logos load from their official/public web assets.

DEMO FLOW:
Overview -> Company Intelligence -> select Microsoft/Goldman Sachs -> Student Skill Gap ->
Submit Experience -> Load demo experience -> Run PII Guard + AI Extraction -> Company Intelligence ->
PII Guard & Privacy -> How the platform works.

IMPORTANT:
This is a hackathon MVP/prototype. Placement experiences and analytics shown are synthetic demo data.
The PII Guard and AI extraction are local browser simulations for the demo; a production system would use
a real backend, database, NLP/LLM service, authentication, moderation and privacy controls.

BRANDING UPDATE:
- NITK Surathkal logo added to the sidebar.
- Smart India Hackathon branding added to the dashboard header and footer.
- Team name “Stack Syndicate” added across the dashboard for hackathon presentation identity.
